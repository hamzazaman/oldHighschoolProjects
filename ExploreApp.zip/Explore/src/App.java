import java.awt.GridLayout;
import java.util.Random;

import javax.swing.*;
public class App {
	public static void main(String[] args) {
		Random r = new Random();
		int[][] field = new int[30][30];
		for (int x = 0; x < 30; x++) {
			for (int y = 0; y < 30; y++) {
				field[x][y] = r.nextInt(5)+1;
			}
		}
		@SuppressWarnings("unused")
		Win1 lay = new Win1(field);
		int pn = Integer.parseInt(args[0]);
		
		Probe[] pl = new Probe[10];
		for(int n = 0; n < pn; n++){
			pl[n] = new Probe(field);
			pl[n].start();
		}
	}
	
}
class Win1 extends JFrame{
	private static final long serialVersionUID = 1L;
	JLabel[][] label;
	Win1(int[][] field){
		try { 
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}
		setTitle("Field");
		setLayout(new GridLayout(30,30));
		label = new JLabel[30][30];
		for (int v = 0; v < 30; v++){
			for (int b = 0; b < 30; b++){
				label[v][b] = new JLabel(Integer.toString(field[v][b]));
				if(field[v][b] == 0){
					label[v][b].setText(" ");
				}
				add(label[v][b]);
			}
		}
		pack();
		setSize(380,450);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
}