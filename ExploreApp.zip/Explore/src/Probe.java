import java.util.Random;

import javax.swing.*;

import java.awt.*;

public class Probe extends Thread {
	static int[][] obs = new int[30][30];
	int[][] field;
	int x;
	int y;
	int d;
	static int num = 1;
	int id;
	public Probe(int[][] field) {
		this.field = field;
		id = num;
		num++;
	}

	public void run() {
		Random rand = new Random();
		x = rand.nextInt(30);
		y = rand.nextInt(30);
		d = rand.nextInt(4);
		Win screen = new Win();
		while (true) {
			if (d == 0 && x > 0) {
				x--;
			} else if (d == 1 && y < 29) {
				y++;
			} else if (d == 2 && x < 29) {
				x++;
			} else if (d == 3 && y > 0) {
				y--;
			} else if (d == 0 && x == 0){
				d = rand.nextInt(4);
			} else if (d == 1 && y == 29){
				d = rand.nextInt(4);
			} else if (d == 2 && x == 29){
				d = rand.nextInt(4);
			} else if (d == 3 && y == 0){
				d = rand.nextInt(4);
			}
			for (int r = rand.nextInt(2); r == 1; r = 0) {
				d = rand.nextInt(4);
			}
			//obs[x][y] = field[x][y];
			obs[x][y] = 10;
			if (x < 29) {
				obs[x + 1][y] = field[x + 1][y];
			}
			if (x < 29 && y < 29) {
				obs[x + 1][y + 1] = field[x + 1][y + 1];
			}
			if (y < 29) {
				obs[x][y + 1] = field[x][y + 1];
			}
			if (x > 0) {
				obs[x - 1][y] = field[x - 1][y];
			}
			if (x > 0 && y > 0) {
				obs[x - 1][y - 1] = field[x - 1][y - 1];
			}
			if (y > 0) {
				obs[x][y - 1] = field[x][y - 1];
			}
			if (x < 29 && y > 0) {
				obs[x + 1][y - 1] = field[x + 1][y - 1];
			}
			if (y < 29 && x > 0) {
				obs[x - 1][y + 1] = field[x - 1][y + 1];
			}
			try {
				sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			screen.update();
		}
	}
	
	class Win extends JFrame{	
		private static final long serialVersionUID = 1L;
		JLabel[][] label;
		Win(){
			try { 
			    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			} catch (Exception e) {
			    e.printStackTrace();
			}
			setTitle("Probe " + id);
			setLayout(new GridLayout(30,30));
			label = new JLabel[30][30];
			for (int v = 0; v < 30; v++){
				for (int b = 0; b < 30; b++){
					label[v][b] = new JLabel(Integer.toString(obs[v][b]));
					if(obs[v][b] == 0){
						label[v][b].setText(" ");
					}
					add(label[v][b]);
				}
			}
			pack();
			setVisible(true);
			setSize(380,450);
		}
		void update() {
			for (int v = 0; v < 30; v++){
				for (int b = 0; b < 30; b++){
					label[v][b].setText(Integer.toString(obs[v][b]));
					if(obs[v][b] == 0){
						label[v][b].setText(" ");
					}
					if(obs[v][b] == 10){
						label[v][b].setText("-");
					}
				}
			}
			label[x][y].setText("@");
			repaint();
		}
	}
}
