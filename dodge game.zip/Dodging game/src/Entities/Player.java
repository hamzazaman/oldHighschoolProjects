package Entities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public class Player implements Entities {
	public static final long SHOTS_PER_SEC = 3;
	public static final long SHOTS_PERIOD_NSEC = 1000000000L /SHOTS_PER_SEC;
	public long timeShot = System.nanoTime();
	public long timeElapse;
	public static final long RELOAD_PERIOD_NSEC = 1000000000L * 8;
	public long timeReload = System.nanoTime();
	static final int WIDTH = 20;
	static final int HEIGHT = 15;
	int x = 150;
	int y = 600 - HEIGHT/2 - 15;
	public int maxX;
	public int maxY;
	// To Store input
	boolean up = false;
	boolean down = false;
	boolean right = false;
	boolean left = false;
	boolean space = false;
	public boolean shoot = false;
	boolean exists = true;
	int hits = 0;
	public int shots = 1;
	boolean shield = false;
	
	public Player(int mx, int my) {
		maxX = mx;
		maxY = my;
	}

	@Override
	public void render(Graphics2D g) {
		g.setColor(Color.GREEN);
		g.fillRoundRect(x - WIDTH / 2, y - HEIGHT / 2, WIDTH, HEIGHT, 6, 6);
		if(shield == true){
			g.setColor(Color.RED);
			g.drawRoundRect(x - WIDTH / 2, y - HEIGHT / 2, WIDTH, HEIGHT, 6, 6);
		}
		//things you draw after here will not be rotated
	}

	@Override
	public int getX() {
		return x;
	}

	@Override
	public int getY() {
		return y;
	}

	@Override
	public void setX(int nx) {
		x = nx;

	}

	@Override
	public void setY(int ny) {
		y = ny;

	}

	public void up(int length) {
		if (y - HEIGHT / 2 > 0)
			setY(getY() - length);
	}

	public void down(int length) {
		if (y + HEIGHT / 2 < maxY)
			setY(getY() + length);
	}

	public void left(int length) {
		if (x - WIDTH / 2 > 0)
			setX(getX() - length);
	}

	public void right(int length) {
		if (x + WIDTH / 2 < maxX)
			setX(getX() + length);
	}

	@Override
	public void move() {
		if (up)
			up(5);
		if (down)
			down(5);
		if (left)
			left(7);
		if (right)
			right(7);
		if (space) {
			if (shots > 0 && System.nanoTime() - timeShot > SHOTS_PERIOD_NSEC) {
				timeShot = System.nanoTime();
				timeReload = System.nanoTime();
				shoot = true;
				shots--;
			}else{
				shoot = false;
			}
		}else{
			shoot = false;
		}
		if (System.nanoTime() - timeReload > RELOAD_PERIOD_NSEC && shots < 3) {
			timeReload = System.nanoTime();
			shots++;
		}

	}

	public void press(int keyCode) {
		switch (keyCode) {
		case KeyEvent.VK_W:
			//up = true;
			break;
		case KeyEvent.VK_S:
			//down = true;
			break;
		case KeyEvent.VK_A:
			left = true;
			break;
		case KeyEvent.VK_D:
			right = true;
			break;
		case KeyEvent.VK_SPACE:
			space = true;
			break;
		case KeyEvent.VK_LEFT:
			left = true;
			break;
		case KeyEvent.VK_RIGHT:
			right = true;
			break;
		}

	}

	public void released(int keyCode) {
		switch (keyCode) {
		case KeyEvent.VK_W:
			//up = false;
			break;
		case KeyEvent.VK_S:
			//down = false;
			break;
		case KeyEvent.VK_A:
			left = false;
			break;
		case KeyEvent.VK_D:
			right = false;
			break;
		case KeyEvent.VK_SPACE:
			space = false;
			break;
		case KeyEvent.VK_LEFT:
			left = false;
			break;
		case KeyEvent.VK_RIGHT:
			right = false;
			break;
		}
	}

	@Override
	public boolean collide(Entities ent) {
		if(ent.getClass() == PowerUp.class)
			return false;
		Rectangle r = new Rectangle(x - WIDTH / 2, y - HEIGHT / 2, WIDTH,
				HEIGHT);
		Rectangle p = new Rectangle(ent.getX() - ent.getWidth() / 2, ent.getY()
				- ent.getHeight() / 2, ent.getWidth(), ent.getHeight());
		if (r.intersects(p)) {
			if(shield == true){
				shield = false;
				return true;
			}
			exists = false;
			return true;
		}
		return false;
	}

	@Override
	public int getWidth() {
		return WIDTH;
	}

	@Override
	public int getHeight() {
		return HEIGHT;
	}

	@Override
	public boolean exist() {
		return exists;
	}
	
	public void powerUp(int power){
		switch (power){
		case 0: shield = true;
			break;
		default: System.out.println("error");
		}
	}

}
