package Entities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Barricade implements Entities {
	int x = 10;
	int y = 10;

	static final int WIDTH = 180;
	static final int HEIGHT = 30;
	private Color health = Color.BLUE;
	boolean collided;
	boolean exists = true;
	int hits = 0;

	@Override
	public void render(Graphics2D g) {
		g.setColor(health);
		g.fillRoundRect(x - WIDTH / 2, y - HEIGHT / 2, WIDTH, HEIGHT,6,6);
	}

	@Override
	public int getX() {
		return x;
	}

	@Override
	public int getY() {
		return y;
	}

	@Override
	public void setX(int nx) {
		x = nx;

	}

	@Override
	public void setY(int ny) {
		y = ny;

	}

	@Override
	public void move() {
		setY(getY() + 5);
		if (!collided)
			health = Color.BLUE;
		collided = false;

	}

	@Override
	public boolean collide(Entities ent) {
		if(ent.getClass() == PowerUp.class)
			return false;
		Rectangle r = new Rectangle(x - WIDTH / 2, y - HEIGHT / 2, WIDTH,
				HEIGHT);
		Rectangle p = new Rectangle(ent.getX() - ent.getWidth() / 2, ent.getY()
				- ent.getHeight() / 2, ent.getWidth(), ent.getHeight());
		if (r.intersects(p)) {
			health = Color.RED;
			collided = true;
			hits++;
			if (hits >= 1) {
				exists = false;
				
			}
			return true;
		}
		return false;
	}

	@Override
	public int getWidth() {
		return WIDTH;
	}

	@Override
	public int getHeight() {
		return HEIGHT;
	}

	@Override
	public boolean exist() {
		return exists;
	}
}
