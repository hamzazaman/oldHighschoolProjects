package Entities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Bullet implements Entities{
	int x = 10;
	int y = 10;
	public static final int WIDTH = 9;
	public static final int HEIGHT = 18;
	boolean exists = true;
	
	@Override
	public void render(Graphics2D g) {
		g.setColor(Color.ORANGE);
		g.fillOval(x - WIDTH/2, y - HEIGHT, WIDTH, WIDTH*2);
		g.setColor(Color.BLACK);
		g.drawOval(x - WIDTH/2, y - HEIGHT, WIDTH, WIDTH*2);
		g.setColor(Color.RED);
		g.fillRect(x - WIDTH/2, y - HEIGHT/2, WIDTH, HEIGHT);
		g.setColor(Color.BLACK);
		g.drawRect(x - WIDTH/2, y - HEIGHT/2, WIDTH, HEIGHT);
		
		
	}

	@Override
	public int getX() {
		return x;
	}

	@Override
	public int getY() {
		return y;
	}

	@Override
	public void setX(int nx) {
		x = nx;
		
	}

	@Override
	public void setY(int ny) {
		y = ny;
		
	}

	@Override
	public void move() {
		setY(getY() - 10);
		
	}

	@Override
	public boolean collide(Entities ent) {
		Rectangle r = new Rectangle(x - WIDTH / 2, y - HEIGHT / 2, WIDTH,
				HEIGHT);
		Rectangle p = new Rectangle(ent.getX() - ent.getWidth() / 2, ent.getY()
				- ent.getHeight() / 2, ent.getWidth(), ent.getHeight());
		if (r.intersects(p)) {
			exists = false;
			return true;
		}
		return false;
	}

	@Override
	public int getWidth() {
		return WIDTH;
		
	}

	@Override
	public int getHeight() {
		return HEIGHT;
		
	}

	@Override
	public boolean exist() {
		// TODO Auto-generated method stub
		return exists;
	}

}
