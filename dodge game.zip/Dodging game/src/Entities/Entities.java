package Entities;

import java.awt.Graphics2D;

public interface Entities {
	public void render (Graphics2D g);
	public int getX();
	public int getY();
	public void setX(int nx);
	public void setY(int ny);
	public int getWidth();
	public int getHeight();
	public void move();
	public boolean collide(Entities ent);
	public boolean exist();
}
