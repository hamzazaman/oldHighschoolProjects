package Entities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class PowerUp implements Entities{
	int x = 0;
	int y = 0;
	public static final int WIDTH = 30;
	public static final int HEIGHT = 30;
	boolean exists = true;
	
	@Override
	public void render(Graphics2D g) {
		g.setColor(Color.MAGENTA);
		g.fillOval(x - WIDTH / 2, y - HEIGHT / 2, WIDTH, HEIGHT);
		
	}

	@Override
	public int getX() {
		
		return x;
	}

	@Override
	public int getY() {
		
		return y;
	}

	@Override
	public void setX(int nx) {
		
		x = nx;
	}

	@Override
	public void setY(int ny) {
		y = ny;
		
	}

	@Override
	public int getWidth() {
		
		return WIDTH;
	}

	@Override
	public int getHeight() {
		
		return HEIGHT;
	}

	@Override
	public void move() {
		setY(getY() + 5);
		
	}

	@Override
	public boolean collide(Entities ent) {
		if(ent.getClass() != Player.class)
			return false;
		Rectangle r = new Rectangle(x - WIDTH / 2, y - HEIGHT / 2, WIDTH,
				HEIGHT);
		Rectangle p = new Rectangle(ent.getX() - ent.getWidth() / 2, ent.getY()
				- ent.getHeight() / 2, ent.getWidth(), ent.getHeight());
		if (r.intersects(p) && ent.getClass() == Player.class) {
			exists = false;
			Player player = (Player) ent;
			player.powerUp(0);
			return true;
		}
		return false;
	}

	@Override
	public boolean exist() {
		
		return exists;
	}
	
}
