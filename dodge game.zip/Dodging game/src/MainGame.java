import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.net.URL;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import Entities.*;

public class MainGame extends JPanel { // main class for the game

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define constants for the game
	static final int CANVAS_WIDTH = 300; // width and height of the game screen
	static final int CANVAS_HEIGHT = 600;
	static int UPDATES_PER_SEC = 110; // number game update per second
	static long UPDATE_PERIOD_NSEC = 1000000000L / UPDATES_PER_SEC; // nanoseconds
	static final int B_PER_SEC = 3; // number game update per second
	static final long B_PERIOD_NSEC = 1000000000L / B_PER_SEC; // nanoseconds
	static final String TITLE = "Dodge";
	long timeBmade;
	long timeBElapse;
	Thread gameThread;
	Thread refresh;
	Image img;
	boolean lastpowerup;

	// Enumeration for the states of the game.
	static enum GameState {
		INITIALIZED, PLAYING, PAUSED, GAMEOVER, DESTROYED
	}

	static GameState state; // current state of the game

	// Define instance variables for the game objects
	Player p;
	Entities[] en;
	int bPassed;
	int position = 0;
	int lastP = 0;

	// Handle for the custom drawing panel
	private GameCanvas canvas;

	// Constructor to initialize the UI components and game objects
	public MainGame() {
		// Initialize the game objects
		gameInit();

		// UI components
		URL url = getClass().getResource("/starstars.jpg");
		if (url == null) {
			System.out.println("Backround image failed to load");
		} else {
			// path is OK
			img = Toolkit.getDefaultToolkit().getImage(url);
		}
		canvas = new GameCanvas();
		canvas.setPreferredSize(new Dimension(CANVAS_WIDTH, CANVAS_HEIGHT));

		setBackground(Color.DARK_GRAY);
		setLayout(new BorderLayout());
		add(canvas);
		refresh = new Thread() {
			@Override
			public void run() {
				while (true) {
					canvas.repaint();
					try {
						Thread.sleep(8);
					} catch (InterruptedException e) {

						e.printStackTrace();
					}
				}
			}

		};
		refresh.start();

		gameStart();
		// gameStart();

	}

	public void gameReset() {
		state = GameState.GAMEOVER;
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		UPDATES_PER_SEC = 110; // number game update per second
		UPDATE_PERIOD_NSEC = 1000000000L / UPDATES_PER_SEC;

		gameInit();
		gameStart();
		// gameStart();
	}

	public void gameInit() {
		en = new Entities[30];
		p = new Player(CANVAS_WIDTH, CANVAS_HEIGHT);
		en[0] = p;
		bPassed = 0;
		lastpowerup = false;
		timeBmade = System.nanoTime();
		state = GameState.INITIALIZED;
	}

	// Shutdown the game, clean up code that runs only once.
	public void gameShutdown() {
		// ......
	}

	// To start and re-start the game.
	public void gameStart() {
		// Create a new thread
		gameThread = new Thread() {
			// Override run() to provide the running behavior of this thread.
			@Override
			public void run() {
				gameLoop();
			}
		};
		// Start the thread. start() calls run(), which in turn calls
		// gameLoop().
		gameThread.start();
	}

	// Run the game loop here.
	private void gameLoop() {
		// Regenerate the game objects for a new game
		// ......
		state = GameState.PLAYING;

		// Game loop
		long beginTime, timeTaken, timeLeft; // in msec
		while (state != GameState.GAMEOVER) {
			beginTime = System.nanoTime();
			if (state == GameState.PLAYING) { // not paused
				// Update the state and position of all the game objects,
				// detect collisions and provide responses.

				gameUpdate();
			}
			// Refresh the display
			// repaint();
			// Delay timer to provide the necessary delay to meet the target
			// rate
			timeTaken = System.nanoTime() - beginTime;
			timeLeft = (UPDATE_PERIOD_NSEC - timeTaken) / 1000000L; // in
																	// milliseconds
			if (timeLeft < 0)
				timeLeft = 0; // set a minimum
			try {
				// Provides the necessary delay and also yields control so that
				// other thread can do work.
				Thread.sleep(timeLeft);
			} catch (InterruptedException ex) {
			}
		}
	}

	// Update the state and position of all the game objects,
	// detect collisions and provide responses.
	public synchronized void gameUpdate() {
		for (int z = 0; z < en.length; z++) {
			if (en[z] != null) {
				for (int s = 0; s < en.length; s++) {
					if (en[s] != null && s != z) {
						if (en[z].collide(en[s])) {
						}
					}
				}

			}
		}
		if (!p.exist()) {
			state = GameState.GAMEOVER;
			return;
		}
		for (int z = 0; z < en.length; z++) {
			if (en[z] != null) {
				if (!en[z].exist()) {
					en[z] = null;
				}
			}
		}
		for (int z = 0; z < en.length; z++) {
			if (en[z] != null) {
				if (en[z].getY() < -100 || en[z].getY() > CANVAS_HEIGHT + 10) {
					if (en[z].getClass().equals(new Barricade().getClass())
							|| p.exist()) {
						bPassed++;
						if (UPDATES_PER_SEC < 300) {
							UPDATES_PER_SEC += 1;
							UPDATE_PERIOD_NSEC = 1000000000L / UPDATES_PER_SEC;
						}
					}
					en[z] = null;
				} else {
					en[z].move();
				}
			}
		}

		if (p.shoot && p.exist()) {
			for (int z = 0; z < en.length; z++) {
				if (en[z] == null) {
					en[z] = new Bullet();
					en[z].setX(p.getX());
					en[z].setY(p.getY()
							- (p.getHeight() / 2 + en[z].getHeight() / 2));

					break;
				}
			}
		}
		Random r = new Random();

		timeBElapse = System.nanoTime() - timeBmade;
		if (timeBElapse > B_PERIOD_NSEC) {
			lastP = position;
			position = r.nextInt(3);
			if (position == lastP) {
				position = r.nextInt(3);
				if (position == lastP) {
					position = r.nextInt(3);
				}
			}
			for (int z = en.length - 1; z >= 0; z--) {
				if (en[z] == null) {
					timeBmade = System.nanoTime();
					en[z] = new Barricade();
					if (position == 0) {
						en[z].setX(45);
						en[z].setY(-10);
					} else if (position == 1) {
						en[z].setX(CANVAS_WIDTH / 2);
						en[z].setY(-10);
					} else {
						en[z].setX(CANVAS_WIDTH - 45);
						en[z].setY(-10);
					}
					break;
				}
			}
			
		}else{
			int power = r.nextInt(1000);
			if (power == 0 && !lastpowerup) {
				lastpowerup = true;
				for (int z = en.length - 1; z >= 0; z--) {
					if (en[z] == null) {
						en[z] = new PowerUp();
						if (position == 0) {
							en[z].setX(45);
							en[z].setY(-100);
						} else if (position == 1) {
							en[z].setX(CANVAS_WIDTH / 2);
							en[z].setY(-100);
						} else {
							en[z].setX(CANVAS_WIDTH - 45);
							en[z].setY(-100);
						}
						break;
					}
				}
			}else{
				lastpowerup = false;
			}
		}
	}

	// Refresh the display. Called back via repaint(), which invoke the
	// paintComponent().
	private void gameDraw(Graphics2D g2d) {
		switch (state) {
		case INITIALIZED:
			// ......
			break;
		case PLAYING:
			for (Entities e : en) {
				if (e != null) {
					e.render(g2d);
				}
			}
			g2d.setColor(Color.RED);
			g2d.setFont(new Font(g2d.getFont().getFontName(), Font.BOLD, 25));
			g2d.drawString("" + bPassed, 20, 30);
			for (int z = 0; z < 3; z++) {
				g2d.setColor(new Color(80, 80, 80));
				g2d.fillOval(CANVAS_WIDTH - 20 - (30 * z), 10, Bullet.WIDTH,
						Bullet.WIDTH * 2);
				g2d.setColor(new Color(50, 50, 50));
				g2d.drawOval(CANVAS_WIDTH - 20 - (30 * z), 10, Bullet.WIDTH,
						Bullet.WIDTH * 2);
				g2d.setColor(new Color(80, 80, 80));
				g2d.fillRect(CANVAS_WIDTH - 20 - (30 * z), 20, Bullet.WIDTH,
						Bullet.HEIGHT);
				g2d.setColor(new Color(50, 50, 50));
				g2d.drawRect(CANVAS_WIDTH - 20 - (30 * z), 20, Bullet.WIDTH,
						Bullet.HEIGHT);
			}
			for (int z = 0; z < p.shots; z++) {

				g2d.setColor(Color.ORANGE);
				g2d.fillOval(CANVAS_WIDTH - 20 - (30 * z), 10, Bullet.WIDTH,
						Bullet.WIDTH * 2);
				g2d.setColor(Color.BLACK);
				g2d.drawOval(CANVAS_WIDTH - 20 - (30 * z), 10, Bullet.WIDTH,
						Bullet.WIDTH * 2);
				g2d.setColor(Color.RED);
				g2d.fillRect(CANVAS_WIDTH - 20 - (30 * z), 20, Bullet.WIDTH,
						Bullet.HEIGHT);
				g2d.setColor(Color.BLACK);
				g2d.drawRect(CANVAS_WIDTH - 20 - (30 * z), 20, Bullet.WIDTH,
						Bullet.HEIGHT);
			}
			break;
		case PAUSED:
			// ......
			break;
		case GAMEOVER:
			for (Entities e : en) {
				if (e != null) {
					e.render(g2d);
				}
			}
			p.render(g2d);
			g2d.setColor(Color.WHITE);
			g2d.setFont(new Font(g2d.getFont().getFontName(), Font.BOLD, 30));
			drawCenteredString("GAME OVER", CANVAS_WIDTH, CANVAS_HEIGHT - 90,
					g2d);
			g2d.setFont(new Font(g2d.getFont().getFontName(), Font.BOLD, 20));
			drawCenteredString("SCORE: " + bPassed, CANVAS_WIDTH,
					CANVAS_HEIGHT, g2d);
			drawCenteredString("R to Reset", CANVAS_WIDTH, CANVAS_HEIGHT + 90,
					g2d);
			break;
		case DESTROYED:
			break;
		default:
			break;
		}
	}

	public void drawCenteredString(String s, int w, int h, Graphics2D g) {
		FontMetrics fm = g.getFontMetrics();
		int x = (w - fm.stringWidth(s)) / 2;
		int y = (fm.getAscent() + (h - (fm.getAscent() + fm.getDescent())) / 2);
		g.drawString(s, x, y);
	}

	// Process a key-pressed event. Update the current state.
	/*
	 * public void gameKeyPressed(int keyCode) { switch (keyCode) { case
	 * KeyEvent.VK_W: up = true; break; case KeyEvent.VK_S: down = true; break;
	 * case KeyEvent.VK_A: left = true; break; case KeyEvent.VK_D: right = true;
	 * break; case KeyEvent.VK_SPACE: space = true; } }
	 */

	/*
	 * public void gameKeyReleased(int keyCode) { switch (keyCode) { case
	 * KeyEvent.VK_W: up = false; break; case KeyEvent.VK_S: down = false;
	 * break; case KeyEvent.VK_A: left = false; break; case KeyEvent.VK_D: right
	 * = false; break; case KeyEvent.VK_SPACE: space = false; } }
	 */

	// Custom drawing panel, written as an inner class.
	class GameCanvas extends JPanel implements KeyListener {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		// Constructor
		public GameCanvas() {
			setFocusable(true); // so that can receive key-events
			requestFocus();
			addKeyListener(this);
			setBackground(Color.BLACK);
		}

		// Override paintComponent to do custom drawing.
		// Called back by repaint().
		@Override
		public void paintComponent(Graphics g) {
			Graphics2D g2d = (Graphics2D) g;
			super.paintComponent(g2d);
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			g2d.setClip(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
			g2d.drawImage(img, 0, 0, null);
			g2d.setStroke(new BasicStroke(2));

			// Draw the game objects

			gameDraw(g2d);
			/*
			 * BufferedImage bufferedImage = new BufferedImage(CANVAS_WIDTH,
			 * CANVAS_HEIGHT, BufferedImage.TYPE_INT_ARGB); Graphics2D g2d =
			 * bufferedImage.createGraphics();
			 * g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
			 * RenderingHints.VALUE_ANTIALIAS_ON); gameDraw(g2d); Graphics2D
			 * g2dComponent = (Graphics2D) g;
			 * 
			 * g2dComponent.drawImage(bufferedImage, null, 0, 0);
			 */
		}

		// KeyEvent handlers
		@Override
		public void keyPressed(KeyEvent e) {
			// gameKeyPressed(e.getKeyCode());
			if (e.getKeyCode() == KeyEvent.VK_R) {
				gameReset();
			}
			p.press(e.getKeyCode());
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// gameKeyReleased(e.getKeyCode());
			p.released(e.getKeyCode());
		}

		@Override
		public void keyTyped(KeyEvent e) {

		}
	}

	// main
	public static void main(String[] args) {
		// Use the event dispatch thread to build the UI for thread-safety.
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frame = new JFrame(TITLE);
				// Set the content-pane of the JFrame to an instance of main
				// JPanel
				MainGame g = new MainGame();
				frame.setContentPane(g); // main JPanel as content
											// pane
				// frame.setJMenuBar(menuBar); // menu-bar (if defined)
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.pack();
				// frame.setResizable(false);
				frame.setLocationRelativeTo(null); // center the application
													// window
				// frame.setResizable(false);
				frame.setVisible(true); // show it
			}
		});
	}

}