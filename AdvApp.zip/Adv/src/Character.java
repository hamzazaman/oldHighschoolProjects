import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Arrays;

import javax.swing.*;

public class Character extends JFrame implements KeyListener, Runnable {
	static int[][] field;
	static int[][] obs;
	int x;
	int y;
	int lx;//last x and y
	int ly;
	String[] inv = new String[5];
	JScrollPane scrollPane; 
	boolean pause = false;
	JLabel[][] label;
	JLabel[] stats = new JLabel[7];
	JPanel pani = new JPanel();
	JPanel pan = new JPanel();
	JTextArea dap = new JTextArea();
	int[] stat = new int[7];

	Character(int[][] f) {
		stat[0] = 100;
		stat[1] = 50;
		field = f;
		obs = new int[field.length][field[1].length];
		init();
		screen();
		x = 0;
		y = 0;
		updVar();
		addKeyListener(this);
		setFocusable(true);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void keyPressed(KeyEvent e) {
		if (pause != true) {
			
			if (e.getKeyChar() == 'w' ) {
				moveUp();
			}
			if (e.getKeyChar() == 's') {
				moveDn();
			}
			if (e.getKeyChar() == 'a') {
				moveLf();
			}
			if (e.getKeyChar() == 'd') {
				moveRt();
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	void init() {
		for (int b = 0; b < field.length; b++) {
			for (int n = 0; n < field[b].length; n++) {
				obs[b][n] = 11;
			}
		}
	}

	void screen() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		dap.setEditable(false);
		dap.setFocusable(false);
		scrollPane = new JScrollPane(dap); 
		dap.append("Hello\n");
		dap.setBackground(pan.getBackground());
		setTitle("Screen");
		pani.setLayout(new GridLayout(30, 30));
		pani.setSize(380, 450);
		label = new JLabel[30][30];
		for (int v = 0; v < 30; v++) {
			for (int b = 0; b < 30; b++) {
				label[v][b] = new JLabel(Integer.toString(obs[v][b]));
				pani.add(label[v][b]);
			}
		}
		pan.setLayout(new GridLayout(0, 3));
		stats[0] = new JLabel("Health: " + Integer.toString(stat[0]),
				SwingConstants.CENTER);
		stats[1] = new JLabel("Water: " + Integer.toString(stat[1]),
				SwingConstants.CENTER);
		pan.add(stats[0]);
		pan.add(stats[1]);
		scrollPane.addKeyListener(this);
		add(scrollPane, BorderLayout.CENTER);
		add(pani, BorderLayout.NORTH);
		add(pan, BorderLayout.SOUTH);
		update();
		pack();
		setSize(450, 600); setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
 
	void moveUp() {
		if (x > 0 && field[x - 1][y] != 1) {
			lx = x;
			ly = y;
			x--;
			if(stat[1] > 0){
				stat[1]--;
			}
			checkTile();
			updVar();
		}
	}

	void moveDn() {
		if (x < 29) {
			lx = x;
			ly = y;
			x++;
			if(stat[1] > 0){
				stat[1]--;
			}
			checkTile();
			updVar();
		}
	}

	void moveLf() {
		if (y > 0 && field[x][y - 1] != 1) {
			lx = x;
			ly = y;
			y--;
			if(stat[1] > 0){
				stat[1]--;
			}
			checkTile();
			updVar();
		}
	}

	void moveRt() {
		if (y < 29) {
			lx = x;
			ly = y;
			y++;
			if(stat[1] > 0){
				stat[1]--;
			}
			checkTile();
			updVar();
		}
	}

	void update() {
		for (int v = 0; v < 30; v++) {
			for (int b = 0; b < 30; b++) {
				if (obs[v][b] == 0) {
					label[v][b].setText(" ");
				} else if (obs[v][b] == 10) {
					label[v][b].setText("@");
				} else if (obs[v][b] == 11) {
					label[v][b].setText("#");
				} else if (obs[v][b] == 3) {
					label[v][b].setText("S");
				} else {
					label[v][b].setText(Integer.toString(obs[v][b]));
				}
			}
		}
		stats[0].setText("Health: " + Integer.toString(stat[0]));
		stats[1].setText("Water: " + Integer.toString(stat[1]));
		dap.setCaretPosition(dap.getDocument().getLength());
		repaint();
	}

	void updVar() {
		if (0 <= x && 29 <= x & 0 <= y && 29 <= y) {
			obs[x][y] = field[x][y];
		}
		obs[x][y] = 10;
		if (x < 29) {
			obs[x + 1][y] = field[x + 1][y];
		}
		if (x < 29 && y < 29) {
			obs[x + 1][y + 1] = field[x + 1][y + 1];
		}
		if (y < 29) {
			obs[x][y + 1] = field[x][y + 1];
		}
		if (x > 0) {
			obs[x - 1][y] = field[x - 1][y];
		}
		if (x > 0 && y > 0) {
			obs[x - 1][y - 1] = field[x - 1][y - 1];
		}
		if (y > 0) {
			obs[x][y - 1] = field[x][y - 1];
		}
		if (x < 29 && y > 0) {
			obs[x + 1][y - 1] = field[x + 1][y - 1];
		}
		if (y < 29 && x > 0) {
			obs[x - 1][y + 1] = field[x - 1][y + 1];
		}
		if (stat[1] <= 0) {
			stat[0] -= 10;
			dap.append("No Water\n");
		}
		if(stat[0] <= 0){
			pause = true;
			dap.append("You Died");
		}
		update();
	}

	void checkTile() {
		if (field[x][y] == 3) {
			stat[0] -= 3;
			addInv("Thorn");
		}else if (field[x][y] == 1 && field[lx][ly] != 1) {
			addInv("Sword");
		}
	}
	
	void addInv(String item) {
		boolean invfull = true;
		int v = 0;
		for(; v < inv.length;v++) {
			if(inv[v] == null){
				invfull = false;
				break;
			} 
		}
		if(invfull == false){
			inv[v] = item;
		}else{
			dap.append("Inventory full.\n");
		}
		dap.append(Arrays.toString(inv)+ "\n");
	}
	
	public void run() {
		while (true) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			update();
		}

	}
}
