import java.applet.*;
import java.awt.*;

public class DemoApp extends Applet{
	
	private static final long serialVersionUID = 1L;
	@Override
	public void init() {
		super.init();
		setSize(1000, 700);
	}
	@Override
	public void paint(Graphics g1) {
		super.paint(g1);
		Graphics2D g = (Graphics2D) g1;
		Expo.setBackground(g, Expo.cyan);
		g.setColor(Color.GREEN);
		Expo.fillArc(g, 500, 300, 100, 50, 0, 270);
		g.setColor(Color.ORANGE);
		g.setStroke(new BasicStroke(3));
		Expo.fillStar(g, 200, 200, 100, 20);
		g.setColor(Color.YELLOW);
		Expo.fillCircle(g, 200, 200, 50);
		
	}
	
}
